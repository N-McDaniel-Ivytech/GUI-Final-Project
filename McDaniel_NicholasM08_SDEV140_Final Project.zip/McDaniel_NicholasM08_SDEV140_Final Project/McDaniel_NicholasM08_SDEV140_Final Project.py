
import tkinter as tk

from tkinter import *

from tkinter import messagebox
from PIL import ImageTk, Image


root=tk.Tk()

root.minsize(700,600)#Setting the size of the 

                    #main window

root.title("Movies and More")#Sets the window title


#The Images
# Creates a canvas widget
canvas= Canvas(root, width=1100, height=700)
canvas.pack()

# Loads image
img=ImageTk.PhotoImage(Image.open("popcorn3.jpg"))
img2=ImageTk.PhotoImage(Image.open("ticket1.jpg"))
img3=ImageTk.PhotoImage(Image.open("Theater5.png"))


# Adds image
canvas.create_image(10, 140, anchor=NW, image=img)
canvas.create_image(840, 140, anchor=NW, image=img2)
canvas.create_image(40, 0, anchor=NW, image=img3)


#These are the options for what the user can buy
l5=tk.Label(root,text="Tickets: Basic Ticket, Vip Ticket, 3D Ticket",font=("Arial", 14))
#the above sets the Labels and the one below sets the placement
l5.place(x=300,y=300)

l6=tk.Label(root,text="Snacks: Salted Popcorn , Butter Popcorn",font=("Arial", 14))
#the same steps are done here 
l6.place(x=300,y=330)


#Tells the user to to put uppercase 
l1=tk.Label(root,text="Enter Item Names(Make sure to add Uppercase to the Start of Each Item)",font=("Arial", 15))

l1.place(x=200,y=500)


#The Label for the input box
l1=tk.Label(root,text="Enter Ticket names",font=("Arial", 14))

l1.place(x=400,y=600)

#The Input box

t1=tk.Entry(root,font=("Arial", 14))

t1.place(x=600,y=600)#position of Input box

#The Second Input Box and label for it
l2=tk.Label(root,text="Enter Snack names",font=("Arial", 14))

l2.place(x=400,y=630)

t2=tk.Entry(root,font=("Arial", 14))

t2.place(x=600,y=630)


#the Exit button with the command root.destroy for exiting the GUI
b3 = tk.Button(root,text="exit",command=root.destroy,font=("Arial", 20))
#the placement of the exit button
b3.place(x=10,y=650)


#calculates the prices fuction
def calc():

 s1=t1.get()#taking input from first box
 s2=t2.get()#taking input from second box and etc
 s3=t1.get()
 s4=t2.get()
 s5=t1.get()

 btickets=s1.split(sep='B')#separating each item 
 psnacks=s2.split(sep='S')
 extickets=s3.split(sep='V')#for vip/ex
 bpopcorn=s4.split(sep='B')#for butter
 edtickets=s5.split(sep='3') #for 3d cant name it with a number
 

 len1=len(btickets)-1#finding the length

 len2=len(psnacks)-1#count starts at 1 so i minus one to make sure the order starts at 0 for each item

 len3=len(extickets)-1
 len4=len(bpopcorn)-1
 len5=len(edtickets)-1
 
 priceOfBTickets=len1*6.99#multiplying by price needed
 priceOfSnacks=len2*1.99
 priceOfExTickets=len3*9.99
 priceOfBpopcorn=len4*2.99
 priceOfEDtickets=len5*10.99

   #displaying in box the price of items being ordered

 s='Basic tickets : {}  Salted Popcorn : {} Vip tickets {} Butter Popcorn {} 3D tickets {} '.format(priceOfBTickets,priceOfSnacks,priceOfExTickets,priceOfBpopcorn, priceOfEDtickets)

 messagebox.showinfo('Prices of Individual Items',s)

 

 #returning prices

 return priceOfBTickets,priceOfSnacks,priceOfExTickets,priceOfBpopcorn,priceOfEDtickets,btickets,psnacks,extickets,edtickets,bpopcorn


def total():

    #collecting prices

 pr_btickets,pr_psnacks,pr_extickets,pr_edtickets,pr_bpopcorn,btickets,psnacks,extickets,edtickets,bpopcorn=calc()

 total=pr_btickets+pr_psnacks+pr_extickets+pr_edtickets+pr_bpopcorn#finding total price

 


 s='Total price : {:5.2f}'.format(total)
    
 

 child_w= Toplevel(root)#creating a window

 child_w.geometry("750x350")#size of window

 child_w.grid_location(x=300,y=300)#location of window

 child_w.title("Total Price") #title 

 #widgets

 label_child= Label(child_w, text= s, font=('Helvetica 15'))

 label_child.place(x=20,y=50)#positioning of label

 

 l2= Label(child_w, text="You Have Ordered These Items", font=('Helvetica 15'))

 l2.place(x=20,y=100)#label
 

 s2=' '.join(t1.get())+"  "+' '.join(t2.get())
 box1=t1.get()

 box2=t2.get()


 l3= Label(child_w, text=s2, font=('Helvetica 13'))

 l3.place(x=20,y=150)#label

 

#creating the buttons

 

# this button  calculates them  separately


b1 = tk.Button(root,text="Calculate Price of Individual Items",command=calc,font=("Arial", 14))

b1.place(x=800,y=660)

 

#the is the total price button

b2 = tk.Button(root,text="Calculate The Price of your Order",command=total,font=("Arial", 14))

b2.place(x=10,y=600)

 



root.mainloop()
